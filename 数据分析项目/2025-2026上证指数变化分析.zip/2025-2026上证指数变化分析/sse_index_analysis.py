﻿import warnings
from datetime import date, timedelta
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd
import requests

warnings.filterwarnings("ignore")

SYMBOL = "sh000001"  # 上证指数（腾讯接口）
TODAY = date.today()
START = TODAY - timedelta(days=365)
END = TODAY

OUT_DIR = Path("d:/sse_task/output")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def max_drawdown(nav: pd.Series):
    running_max = nav.cummax()
    drawdown = nav / running_max - 1
    mdd = drawdown.min()
    mdd_end = drawdown.idxmin()
    mdd_start = nav.loc[:mdd_end].idxmax()
    return mdd, mdd_start, mdd_end, drawdown


def fetch_sse_last_year(symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
    url = (
        "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
        f"param={symbol},day,{start_date},{end_date},1000,qfq"
    )
    session = requests.Session()
    session.trust_env = False  # 忽略系统代理，避免代理导致请求失败
    resp = session.get(url, timeout=20)
    resp.raise_for_status()

    obj = resp.json()
    series = obj.get("data", {}).get(symbol, {}).get("day", [])
    if not series:
        raise RuntimeError("未抓取到数据，请检查网络或数据源可用性。")

    df = pd.DataFrame(series, columns=["date", "open", "close", "high", "low", "volume"])
    df["date"] = pd.to_datetime(df["date"])
    for col in ["open", "close", "high", "low", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["close"]).sort_values("date").set_index("date")
    return df


def main():
    start_str = START.isoformat()
    end_str = END.isoformat()
    df = fetch_sse_last_year(SYMBOL, start_str, end_str)

    data = df[["open", "high", "low", "close", "volume"]].copy()
    data["price"] = data["close"]
    data["ret"] = data["price"].pct_change()
    data = data.dropna(subset=["ret"])
    data["rolling_vol_20d_ann"] = data["ret"].rolling(20).std(ddof=1) * np.sqrt(252)

    nav = (1 + data["ret"]).cumprod()
    cum_return = nav.iloc[-1] - 1

    n_days = len(data)
    annual_factor = 252
    ann_return = nav.iloc[-1] ** (annual_factor / n_days) - 1 if n_days > 0 else np.nan
    ann_vol = data["ret"].std(ddof=1) * np.sqrt(annual_factor)
    sharpe = ann_return / ann_vol if ann_vol > 0 else np.nan
    win_rate = (data["ret"] > 0).mean()

    mdd, mdd_start, mdd_end, drawdown = max_drawdown(nav)

    stats = {
        "symbol": SYMBOL,
        "date_start": str(data.index.min().date()),
        "date_end": str(data.index.max().date()),
        "trading_days": int(n_days),
        "cumulative_return": float(cum_return),
        "annualized_return": float(ann_return),
        "annualized_volatility": float(ann_vol),
        "sharpe_ratio_rf0": float(sharpe),
        "daily_win_rate": float(win_rate),
        "max_drawdown": float(mdd),
        "max_drawdown_start": str(mdd_start.date()),
        "max_drawdown_end": str(mdd_end.date()),
        "best_day_return": float(data["ret"].max()),
        "worst_day_return": float(data["ret"].min()),
        "daily_return_mean": float(data["ret"].mean()),
        "daily_return_std": float(data["ret"].std(ddof=1)),
    }

    data_out = data.copy()
    data_out["cum_nav"] = nav
    data_out["drawdown"] = drawdown
    data_out.to_csv(OUT_DIR / "sse_index_last_year.csv", index_label="date", encoding="utf-8-sig")

    pd.Series(stats).to_csv(OUT_DIR / "sse_return_stats.csv", header=["value"], encoding="utf-8-sig")

    fig, axes = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
    axes[0].plot(data.index, data["price"], label="Index Price", color="#1f77b4", lw=1.8)
    axes[0].set_title("SSE Composite (000001) - Last 1 Year")
    axes[0].set_ylabel("Price")
    axes[0].grid(alpha=0.2)

    ax2 = axes[0].twinx()
    ax2.plot(data.index, nav, label="Cumulative NAV", color="#ff7f0e", lw=1.4)
    ax2.set_ylabel("NAV")

    lines1, labels1 = axes[0].get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    axes[0].legend(lines1 + lines2, labels1 + labels2, loc="upper left")

    axes[1].fill_between(data.index, drawdown.values, 0, color="#d62728", alpha=0.35)
    axes[1].set_title("Drawdown")
    axes[1].set_ylabel("Drawdown")
    axes[1].grid(alpha=0.2)

    plt.tight_layout()
    plt.savefig(OUT_DIR / "sse_price_nav_drawdown.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.hist(data["ret"], bins=40, color="#2ca02c", alpha=0.75, edgecolor="white")
    ax.axvline(data["ret"].mean(), color="black", linestyle="--", linewidth=1.2, label="Mean")
    ax.set_title("Daily Return Distribution - SSE Composite (Last 1 Year)")
    ax.set_xlabel("Daily Return")
    ax.set_ylabel("Frequency")
    ax.grid(alpha=0.2)
    ax.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "sse_daily_return_distribution.png", dpi=150)
    plt.close(fig)

    monthly_return = data["price"].resample("ME").last().pct_change().dropna()
    monthly_df = pd.DataFrame(
        {
            "year": monthly_return.index.year,
            "month": monthly_return.index.month,
            "monthly_return": monthly_return.values,
        }
    )
    heatmap_df = monthly_df.pivot(index="year", columns="month", values="monthly_return").sort_index()
    heatmap_df = heatmap_df.reindex(columns=range(1, 13))

    fig, ax = plt.subplots(figsize=(12, max(3.6, 1.2 * len(heatmap_df.index))))
    cmap = LinearSegmentedColormap.from_list("ret_cmap", ["#2c7bb6", "#f7f7f7", "#d7191c"])
    arr = heatmap_df.values
    vmax = np.nanmax(np.abs(arr)) if np.isfinite(arr).any() else 0.01
    vmax = max(vmax, 0.01)
    im = ax.imshow(arr, cmap=cmap, aspect="auto", vmin=-vmax, vmax=vmax)

    month_labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    ax.set_xticks(np.arange(12))
    ax.set_xticklabels(month_labels)
    ax.set_yticks(np.arange(len(heatmap_df.index)))
    ax.set_yticklabels([str(y) for y in heatmap_df.index])
    ax.set_title("Monthly Return Heatmap - SSE Composite")
    ax.set_xlabel("Month")
    ax.set_ylabel("Year")

    for i in range(arr.shape[0]):
        for j in range(arr.shape[1]):
            val = arr[i, j]
            if np.isfinite(val):
                text_color = "white" if abs(val) > vmax * 0.55 else "black"
                ax.text(j, i, f"{val:.1%}", ha="center", va="center", color=text_color, fontsize=8)

    cbar = plt.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
    cbar.set_label("Monthly Return")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "sse_monthly_return_heatmap.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(data.index, data["rolling_vol_20d_ann"], color="#9467bd", lw=1.6, label="20D Rolling Ann Vol")
    ax.set_title("Rolling Volatility - SSE Composite (20D Annualized)")
    ax.set_xlabel("Date")
    ax.set_ylabel("Volatility")
    ax.grid(alpha=0.2)
    ax.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "sse_rolling_volatility_20d.png", dpi=150)
    plt.close(fig)

    print("=== 上证指数近一年收益率统计 ===")
    print(f"数据区间: {stats['date_start']} ~ {stats['date_end']} (交易日: {stats['trading_days']})")
    print(f"累计收益率: {stats['cumulative_return']:.2%}")
    print(f"年化收益率: {stats['annualized_return']:.2%}")
    print(f"年化波动率: {stats['annualized_volatility']:.2%}")
    print(f"Sharpe(无风险利率=0): {stats['sharpe_ratio_rf0']:.3f}")
    print(f"胜率: {stats['daily_win_rate']:.2%}")
    print(f"最大回撤: {stats['max_drawdown']:.2%} ({stats['max_drawdown_start']} -> {stats['max_drawdown_end']})")
    print(f"最佳单日收益: {stats['best_day_return']:.2%}")
    print(f"最差单日收益: {stats['worst_day_return']:.2%}")
    print(f"\n输出目录: {OUT_DIR}")


if __name__ == "__main__":
    main()
