

// ==============================
// DID模型构建完整代码
// 数据要求：city变量为城市名称，year变量为年份
// ==============================

clear all
set memory 2g

// 假设数据已加载，若需导入数据请取消注释
use "C:\Users\63446\Desktop\data_all.dta", clear

// 确保城市名称格式统一（删除首尾空格）
replace city = strtrim(city)

* 对每个变量进行0-1标准化并替换原变量
foreach var in GDP CAP TRADE FDI STRU light {
    quietly summarize `var', meanonly    // 计算变量的最小值和最大值
    replace `var' = (`var' - r(min)) / (r(max) - r(min))  // 替换原变量
}

* 检查结果
summarize GDP  CAP TRADE FDI STRU light

// ==================== 第一步：生成处理组变量treat ====================
// 实验组城市列表（与数据中city名称严格匹配）
gen treat = 0
// 第一段城市列表（每段不超过250个元素）
local group1 "威海市 日照市 芜湖市 蚌埠市 安庆市 滁州市 宿州市 六安市 淮南市 马鞍山市 淮北市 铜陵市 黄山市 池州市 邯郸市 邢台市 开封市 安阳市 新乡市 许昌市 南阳市 商丘市 信阳市 驻马店市 焦作市 漯河市 鹤壁市 三门峡市 运城市 晋中市 临汾市 阳泉市"

// 第二段城市列表
local group2 "株洲市 湘潭市 衡阳市 郴州市 岳阳市 襄阳市 宜昌市 荆州市 赣州市 九江市 上饶市 宜春市 阜阳市 柳州市 桂林市 遵义市 绵阳市 南充市 宝鸡市 咸阳市 临沂市"

// 分批次替换
foreach city in `group1' {
    replace treat = 1 if city == "`city'"
}

foreach city in `group2' {
    replace treat = 1 if city == "`city'"
}


// 验证处理组标记
tab city if treat == 1  // 应显示所有处理组城市


// ==================== 第二步：匹配高铁开通年份 ====================
// 方法：使用merge确保精确匹配
preserve
clear
// 创建高铁开通年份映射表
input str10 city int hsr_year
"威海市" 2014
"日照市" 2018
"芜湖市" 2015
"蚌埠市" 2012
"安庆市" 2015
"滁州市" 2020
"宿州市" 2019
"六安市" 2019
"淮南市" 2012
"马鞍山市" 2015
"淮北市" 2017
"铜陵市" 2015
"黄山市" 2015
"池州市" 2015
"邯郸市" 2012
"邢台市" 2012
"开封市" 2014
"安阳市" 2012
"新乡市" 2012
"许昌市" 2016
"南阳市" 2019
"商丘市" 2016
"信阳市" 2019
"驻马店市" 2012
"焦作市" 2015
"漯河市" 2012
"鹤壁市" 2012
"三门峡市" 2012
"运城市" 2014
"晋中市" 2014
"临汾市" 2014
"阳泉市" 2014
"株洲市" 2014
"湘潭市" 2014
"衡阳市" 2014
"郴州市" 2014
"岳阳市" 2011
"襄阳市" 2019
"宜昌市" 2012
"荆州市" 2020
"赣州市" 2019
"九江市" 2017
"上饶市" 2014
"宜春市" 2014
"阜阳市" 2019
"柳州市" 2013
"桂林市" 2013
"遵义市" 2018
"绵阳市" 2014
"南充市" 2015
"宝鸡市" 2013
"咸阳市" 2020
"临沂市" 2019
end
tempfile hsr_data
save `hsr_data'
restore

// 合并高铁开通年份
merge m:1 city using `hsr_data', keep(master match) nogen

// 生成原始数据（需在数据清洗前执行）
preserve
clear
input str10 city
"三门峡市"  
"上饶市"    
"临汾市"    
"临沂市"    
"乐山市"    
"九江市"    
"云浮市"    
"信阳市"    
"六安市"    
"内江市"    
"南充市"    
"南阳市"    
"咸阳市"    
"商丘市"    
"商洛市"    
"天水市"    
"威海市"    
"安庆市"    
"安康市"    
"安阳市"    
"宜宾市"    
"宜昌市"    
"宜春市"    
"宝鸡市"    
"宿州市"    
"巴中市"    
"广元市"    
"庆阳市"    
"延安市"    
"开封市"    
"揭阳市"    
"新乡市"    
"日照市"    
"晋中市"    
"柳州市"    
"株洲市"    
"桂林市"    
"梅州市"    
"榆林市"    
"汉中市"    
"汕尾市"    
"池州市"    
"河池市"    
"淮北市"    
"淮南市"    
"清远市"    
"湘潭市"    
"滁州市"    
"漯河市"    
"焦作市"    
"玉林市"    
"白银市"    
"百色市"    
"眉山市"    
"绵阳市"    
"芜湖市"    
"荆州市"    
"蚌埠市"    
"衡阳市"    
"襄阳市"    
"许昌市"    
"贵港市"    
"资阳市"    
"赣州市"    
"达州市"    
"运城市"    
"遂宁市"    
"遵义市"    
"邢台市"    
"邯郸市"    
"郴州市"    
"钦州市"    
"铜陵市"    
"阜阳市"    
"阳江市"    
"阳泉市"    
"雅安市"    
"韶关市"    
"马鞍山市"    
"驻马店市"    
"鹤壁市"    
"黄山市"    
end


// 省份映射
gen province = ""
local henan "三门峡市 信阳市 南阳市 安阳市 开封市 新乡市 漯河市 焦作市 许昌市 驻马店市 鹤壁市 商丘市"
foreach c in `henan' {
    replace province = "河南" if city == "`c'"
}

local jiangxi "上饶市 九江市 宜春市 赣州市"
foreach c in `jiangxi' {
    replace province = "江西" if city == "`c'"
}

local shanxi "临汾市 晋中市 运城市 阳泉市 吕梁市 朔州市 忻州市"
foreach c in `shanxi' {
    replace province = "山西" if city == "`c'"
}

local sichuan "宜宾市"
foreach c in `sichuan' {
    replace province = "四川" if city == "`c'"
}

local shandong "临沂市 威海市 日照市 东营市 滨州市 菏泽市 聊城市"
foreach c in `shandong' {
    replace province = "山东" if city == "`c'"
}

local sichuan "乐山市 内江市 南充市 巴中市 广元市 眉山市 绵阳市 达州市 遂宁市 资阳市 雅安市 自贡市 泸州市"
foreach c in `sichuan' {
    replace province = "四川" if city == "`c'"
}

local anhui "六安市 安庆市 宿州市 池州市 淮北市 淮南市 滁州市 芜湖市 蚌埠市 铜陵市 阜阳市 黄山市 马鞍山市"
foreach c in `anhui' {
    replace province = "安徽" if city == "`c'"
}

local guangdong "云浮市 揭阳市 梅州市 汕尾市 清远市 阳江市 韶关市 河源市 茂名市"
foreach c in `guangdong' {
    replace province = "广东" if city == "`c'"
}

local guangxi "柳州市 桂林市 玉林市 贵港市 钦州市 河池市 百色市"
foreach c in `guangxi' {
    replace province = "广西" if city == "`c'"
}

local shaanxi "咸阳市 宝鸡市 延安市 榆林市 汉中市 安康市 商洛市"
foreach c in `shaanxi' {
    replace province = "陕西" if city == "`c'"
}

local hubei "宜昌市 襄阳市 荆州市"
foreach c in `hubei' {
    replace province = "湖北" if city == "`c'"
}

local hunan "株洲市 湘潭市 衡阳市 郴州市 岳阳市"
foreach c in `hunan' {
    replace province = "湖南" if city == "`c'"
}

local gansu "天水市 白银市 庆阳市 陇南市 平凉市"
foreach c in `gansu' {
    replace province = "甘肃" if city == "`c'"
}

local guizhou "遵义市 六盘水市 安顺市 毕节市"
foreach c in `guizhou' {
    replace province = "贵州" if city == "`c'"
}

local hebei "邢台市 邯郸市 保定市 张家口市"
foreach c in `hebei' {
    replace province = "河北" if city == "`c'"
}

// 区域划分（国家统计局2023标准）
gen region = ""
replace region = "东部" if inlist(province, "山东", "广东", "河北", "辽宁", "江苏", "浙江", "福建")
replace region = "中部" if inlist(province, "山西", "安徽", "江西", "河南", "湖北", "湖南")
replace region = "西部" if inlist(province, "四川", "陕西", "甘肃", "广西", "贵州", "云南")

// 保存映射关系
save "city_province_region.dta", replace
restore

// 合并到主数据
merge m:1 city using "city_province_region.dta", keep(match master) nogenerate

list city if missing(province)  
//补充缺失值
tab province region, mi        // 检查区域划分逻辑
replace region = "东部" if inlist(province, "山东", "广东", "河北", "辽宁", "江苏", "浙江", "福建")
replace region = "中部" if inlist(province, "山西", "安徽", "江西", "河南", "湖北", "湖南")
replace region = "西部" if inlist(province, "四川", "陕西", "甘肃", "广西", "贵州", "云南")
// 输出样例
list city province region in 1/10, sep(0)


replace hsr_year = 2012 if city == "三门峡市"
replace hsr_year = 2015 if city == "马鞍山市"
replace hsr_year = 2012 if city == "驻马店市"
* 补充省份（province）和区域（region）列
replace province = "河南省" if city == "三门峡市"
replace region = "中部" if city == "三门峡市"

replace province = "山东省" if city == "东营市"
replace region = "东部" if city == "东营市"

replace province = "山西省" if city == "吕梁市"
replace region = "中部" if city == "吕梁市"

replace province = "山西省" if city == "忻州市"
replace region = "中部" if city == "忻州市"

replace province = "山西省" if city == "朔州市"
replace region = "中部" if city == "朔州市"

replace province = "山东省" if city == "滨州市"
replace region = "东部" if city == "滨州市"

replace province = "山东省" if city == "聊城市"
replace region = "东部" if city == "聊城市"

replace province = "山东省" if city == "菏泽市"
replace region = "东部" if city == "菏泽市"

replace province = "安徽省" if city == "马鞍山市"
replace region = "中部" if city == "马鞍山市"

replace province = "河南省" if city == "驻马店市"
replace region = "中部" if city == "驻马店市"
// ==================== 第三步：生成DID核心变量 ====================
// 生成post变量（处理组开通高铁后为1）
gen post = (year >= hsr_year) if treat == 1
replace post = 0 if missing(post)  // 对照组和未开通时期设为0

// 生成交互项
gen HSR = treat * post

// ==================== 第五步：数据验证 ====================
// 检查处理组开通年份是否匹配
list city hsr_year if treat == 1 & !missing(hsr_year), sep(0)
count if treat == 1 & missing(hsr_year)  // 为0

// 检查样本分布
tab year HSR
tab city if HSR == 1  // 应显示处理组开通后的城市
replace GDP=ln(GDP)

/****** PSM匹配 ​******/
// 执行倾向得分匹配
psmatch2 treat one_GDP second third students , logit neighbor(2) caliper(0.2) common
pstest one_GDP second third students, both graph  			

*try other psm

*psmatch2 treat one_GDP second third students , out(GDP) logit ate neighbor(1) caliper(0.1) common ties
*pstest  one_GDP second third students, both graph  			


*psmatch2 treat one_GDP second third students , out(GDP) logit ate neighbor(4) caliper(0.01) common ties
*pstest  one_GDP second third students, both graph  			


*psmatch2 treat one_GDP second third students , out(GDP) radius caliper(0.01)
*pstest  one_GDP second third students, both graph  			

*psmatch2 treat one_GDP second third students , out(GDP) kernel 
*pstest  one_GDP second third students, both graph  			


// 先提取倾向得分
logit treat one_GDP second third students
predict pscore, xb  // 生成倾向得分

// 绘制处理组与控制组的倾向得分分布
graph twoway (kdensity pscore if treat == 1, lcolor(red) title("倾向得分分布")) ///
            (kdensity pscore if treat == 0, lcolor(blue)), legend(order(1 "处理组" 2 "控制组"))

		 //效果不好
psmatch2 treat one_GDP second third students, logit neighbor(2) caliper(0.2) common 
psmatch2 treat one_GDP second third students, ///
    logit kernel caliper(0.) common  // 核匹配设置       
graph twoway (kdensity _pscore if treat == 1, lcolor(red)) ///
         (kdensity _pscore if treat == 0, lcolor(blue))



// 3. 绘制倾向得分共同支撑图
graph twoway ///
    (kdensity pscore if treat == 1, lcolor(red)) /// 绘制处理组密度曲线
    (kdensity pscore if treat == 0, lcolor(blue)) /// 绘制控制组密度曲线
    , title("倾向得分共同支撑") xlabel(, format(%9.3f)) /// 设置标题和横轴格式
      legend( /// 统一设置图例
          order(1 "处理组" 2 "控制组") /// 定义图例顺序和标签
          pos(1) ring(0) /// 可选：调整图例位置
      )


// ==============================
// DID模型实证分析构建完整代码
// 数据要求：city变量为城市名称，year变量为年份
// ==============================

/****** 第一部分：基准回归 ​******/
// 多期DID回归（GDP为因变量）
reghdfe GDP HSR CAP TRADE FDI STRU, absorb(city year) cluster(city)

reghdfe GDP HSR CAP TRADE FDI STRU, absorb(city year) vce(robust)


// 平行趋势检验（生成事件研究图）
// 生成相对时间变量（处理缺失值）
gen rel_year = year - hsr_year if !missing(hsr_year)
//使用 reghdfe,吸收city、year的固定效应，聚类标准误至城市层面，处理异方差问题
// 创建合法的时间虚拟变量名称（-5到5年窗口期）
forval j = 0/10 {
    local t = `j' - 5  // 将循环变量 j（0到10）转换为 -5到+5` 的时间窗口
    gen rel_time_`j' = (rel_year == `t') if !missing(rel_year)
}
//为每个时间窗口创建虚拟变量，若 rel_year 等于当前窗口值（如 -5、+3 等），则赋值为 1，否则为 0。
// 设置基准期（-1年）
drop rel_time_5  // 对应t=-0的情况（如果需要）

// 验证变量创建
sum rel_time_*

// 执行事件研究回归
reghdfe GDP rel_time_* CAP TRADE FDI STRU, absorb(city year) cluster(city)

// 绘制修正后的平行趋势图
coefplot, keep(rel_time_*) ///
    order(rel_time_0 rel_time_1 rel_time_2 rel_time_3 rel_time_4 rel_time_6 rel_time_7 rel_time_8 rel_time_9 rel_time_10) ///
    yline(0) xline(5.5, lpattern(dash)) ///
    xtitle("相对时间（基准期：-1年）") ///
    coeflabels(rel_time_0 = "-5" rel_time_1 = "-4" rel_time_2 = "-3" rel_time_3 = "-2" rel_time_4 = "-1" ///
               rel_time_6 = "+1" rel_time_7 = "+2" rel_time_8 = "+3" rel_time_9 = "+4" rel_time_10 = "+5")
			   
			   
/****** 第二部分：空间溢出效应 ​******/



/*--------------------------------------------------
 第三部分：区域异质性分析
--------------------------------------------------*/
// 分区域回归
***先划分区域
/**********************************************
* 中国城市-省份-区域映射关系
* 数据来源：民政部2023年行政区划代码
* 最后更新：2023-10-15
**********************************************/


***分区域回归

// 多期DID回归（GDP为因变量）

reghdfe GDP HSR CAP TRADE FDI STRU if region=="东部", absorb(city year) vce(robust)
reghdfe GDP HSR CAP TRADE FDI STRU if region=="中部", absorb(city year) vce(robust)
reghdfe GDP HSR CAP TRADE FDI STRU if region=="西部", absorb(city year) vce(robust)






/****** 第四部分：机制检验 ​******/
// 中介效应检验（产业结构渠道）
sgmediation GDP, iv(HSR) mv(second_rate) cv(CAP TRADE FDI STRU)
//第三产业比例
sgmediation GDP, iv(HSR) mv( third_rate) cv(CAP TRADE FDI STRU)


*******************稳健性检验

//•	替换变量：用夜间灯光亮度替换GDP
reghdfe light  HSR CAP TRADE FDI STRU , absorb(city year) vce(robust)




//•	排除干扰：控制机场、高速公路等交通基础设施变量

reghdfe GDP   HSR CAP TRADE FDI STRU urbanization , absorb(city year) vce(robust)


/*==================================================
 安慰剂检验完整方案
==================================================*/

encode city, gen(city_code)  // 生成新变量 city_code（数值型）
drop city                    // 可选：删除原始字符串变量
rename city_code city        // 可选：将新变量重命名为 city
* 设置面板数据
xtset city year  // city为城市ID，year为2000-2012（共13年）

* 基准DID回归（假设高铁开通变量为HSR_did）
reghdfe GDP HSR CAP TRADE FDI STRU, absorb(city year) cluster(city)
estimates store did_base  // 存储基准回归结果



* 时间安慰剂检验（核心代码）
didplacebo did_base, treatvar(HSR) pbotime(1(1)5) seed(223) ///
  savegraph("时间安慰剂检验") rep(500)




